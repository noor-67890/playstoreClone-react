import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './components/Navbar';
import Buttons from './components/Buttons';
import Slider from './components/Slider';
import Recommend from './components/Recommend';
import Footer from './components/Footer';
import Img from './components/Img';
import Icons from './components/Icons';
const App = () => {
  
  return (
    <div>
    <Navbar/>
    <Buttons/>
    <Slider/>
    <Recommend/>
    <Img/>
    <Icons/>
    <Footer/>
    </div>
  )
}

export default App




