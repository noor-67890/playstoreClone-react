import React from 'react';

const Img = () => {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
      <img
        src='https://play-lh.googleusercontent.com/w_i8BPih7PC3qICd7Z_LZ7DaPvep8mrk2ekXd8ObE2n-tZsyarwcmEjCtz-qlJ_dgeN8wqlXJbA=w648-h364-rw'
        alt='image1'
        style={{
          borderRadius: '10px',
          width: '1300px',
          height: '350px',
        }}
      />
    </div>
  );
};

export default Img;
