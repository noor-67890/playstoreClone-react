import React from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';

import { BsSearch, BsPersonFill } from 'react-icons/bs';

const Navbarr = () => {
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="#home">
          <img
            src="https://www.freepnglogos.com/uploads/google-play-png-logo/arrow-andorid-google-google-play-logo-market-media-play-png-logo-11.png"
            alt="Google Play"
            height="30"
            width="30"
            className="d-inline-block align-top"
          />
          {' Google Play'}
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="#home">Games</Nav.Link>
            <Nav.Link href="#link" className="active fw-bold" style={{ color: 'green', textDecoration: 'underline' }}>
              Apps
            </Nav.Link>
            <Nav.Link href="#link">Movies & TV</Nav.Link>
            <Nav.Link href="#link">Books</Nav.Link>
            <Nav.Link href="#link">Kids</Nav.Link>
          </Nav>
          <div className="d-flex align-items-center">
            <div className="me-3">
              <div className="input-group">
                <input type="text" className="form-control" placeholder="Search" />
                <button type="button" className="btn btn-outline-primary"><BsSearch /></button>
              </div>
            </div>
            <div>
              <button type="button" className="btn btn-primary btn-danger"><BsPersonFill /></button>
            </div>
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Navbarr;
