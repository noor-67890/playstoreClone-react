import React from 'react';
import Button from 'react-bootstrap/Button';
import { BsPhone, BsTablet, BsTv, BsLaptop, BsWatch } from 'react-icons/bs';

const Buttons = () => {
  const buttonsData = [
    { icon: <BsPhone className="me-1" />, label: 'Phone' },
    { icon: <BsTablet className="me-1" />, label: 'Tablets' },
    { icon: <BsTv className="me-1" />, label: 'TV' },
    { icon: <BsLaptop className="me-1" />, label: 'Chromebook' },
    { icon: <BsWatch className="me-1" />, label: 'Watch' }
  ];

  return (
    <div className="mt-3 d-flex justify-content-center">
      {buttonsData.map((button, index) => (
        <Button
          key={index}
          variant="outline-dark"
          className="me-2"
          style={{ padding: '10px' }}
        >
          {button.icon}
          <span className="fw-bold">{button.label}</span>
        </Button>
      ))}
    </div>
  );
}

export default Buttons;
