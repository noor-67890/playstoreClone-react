import React, { useState } from 'react';
import { Card } from 'react-bootstrap';

const Icons = () => {
  const cardData = [
    {
      rank: '1',
      imageSrc: 'https://play-lh.googleusercontent.com/Nz5sdWyh7jn4eTy_GSaRBDgaKhLC1pvYywC6fklDOlPGbopmeFN9NkqgKGjsvJMbKVEI=s64-rw',
      title: 'Temu: Shop Like a Billionaire',
      category: 'Shopping'
    },
    {
      rank: '2',
      imageSrc: 'https://play-lh.googleusercontent.com/G6jK9S77RN0laf9_6nhDo3AVxbRP9SgMmt8ZmQjKQ2hibn9xhOY-W5YFn_7stJD1CA=s64-rw',
      title: 'Threads, an Instagram app',
      category: 'Social'
    },
    {
      rank: '3',
      imageSrc: 'https://play-lh.googleusercontent.com/xDh13mMPU9Z0cuPybhWla8k8LsjhgMmDi7XSKKFjyazb0Rohn3EDXNq9blytK-dVfDQw=s64-rw',
      title: 'Remini - AI Photo Enhancer',
      category: 'Photography'
    },
    {
      rank: '4',
      imageSrc: 'https://play-lh.googleusercontent.com/VODqBhdZXQIkQlcv_A2nAq1gPNO7fwfDlUO3UZcgcMy6jAVx05CSU-vFuVFsr9gFUuo=s64-rw',
      title: 'Max: Stream TV, & Movies',
      category: 'Entertainment'
    },
    {
      rank: '5',
      imageSrc: 'https://play-lh.googleusercontent.com/OS-MhSWOPtlUZLt0_UP5TI4juSf0XhyHxGfJa6pA-UIYkZ1BB6QHTZwaMEzZDPqYsmk=s64-rw',
      title: 'TikTok',
      category: 'Social'
    },
    {
      rank: '6',
      imageSrc: 'https://play-lh.googleusercontent.com/e9FXWFNT_9cL6yPiITu38t3wNLXd5lxohnq1tQQGJhvqsWw-pf4FnDX9zhod5R1jag=s64-rw',
      title: 'SHEIN-Shopping Online',
      category: 'Shopping'
    }
  ];

  
  
  
  const [selectedCategory, setSelectedCategory] = useState('All');

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  let filteredCards = cardData;

  if (selectedCategory === 'Top free') {
    // Show top free cards
    filteredCards = cardData;
  } else if (selectedCategory === 'Top grossing') {
    // Show top grossing cards
    filteredCards = cardData.filter(card => card.category === 'Shopping');
  } else if (selectedCategory === 'Top paid') {
    // Show top paid cards
    filteredCards = cardData.filter(card => card.category === 'Social');
  }

  return (
    <div>
      <h5 className="me-2 mt-4 p-1" style={{ marginLeft: '120px' }}>Top Charts</h5>
      <div className="mt-3 ml-4 d-flex flex-wrap" style={{ marginLeft: '120px' }}>
        <Card
          className={`me-2 p-1 ${selectedCategory === 'Top free' }`}
          onClick={() => handleCategoryChange('Top free')}
          style={{ backgroundColor: 'green' , color: 'white' }}
        >
          <Card.Body>Top free</Card.Body>
        </Card>
        <Card
          className={`me-2 p-1 ${selectedCategory === 'Top grossing' }`}
          onClick={() => handleCategoryChange('Top grossing')}
          style={{ cursor: 'pointer' }}
        >
          <Card.Body>Top grossing</Card.Body>
        </Card>
        <Card
          className={`p-1 ${selectedCategory === 'Top paid' }`}
          onClick={() => handleCategoryChange('Top paid')}
          style={{ cursor: 'pointer' }}
        >
          <Card.Body>Top paid</Card.Body>
        </Card>
      </div>
      <div className="mt-3 d-flex flex-wrap justify-content-center align-items-center" style={{ marginLeft: '120px' }}>
        <div className="d-flex flex-wrap">
          {filteredCards.map((card, index) => (
            <Card
              key={index}
              className={`bg-white text-dark p-2 rounded d-flex align-items-center me-3 ${index >= 3 ? 'mt-3' : ''}`}
              style={{
                width: '400px',
                height: 'auto',
                marginLeft: '0',
                border: 'none',
                flexDirection: 'row',
                color: selectedCategory === card.category ? 'white' : '',
                backgroundColor: selectedCategory === card.category ? 'green' : ''
              }}
            >
              <img
                src={card.imageSrc}
                alt="nothing"
                className="me-3"
                style={{ width: '100px', height: '100px', objectFit: 'cover' }}
              />
              <div style={{ flex: '1' }}>
                <h6 className="m-0 font-weight-bold" style={{ fontSize: '18px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', color: selectedCategory === card.category ? 'white' : 'black' }}>{card.title}</h6>
                <p className="m-0" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', color: selectedCategory === card.category ? 'white' : 'black' }}>{card.category}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Icons;