import Carousel from 'react-bootstrap/Carousel';

function Slider() {
  return (
    <div>
    <div className="d-flex justify-content-center mt-5">
      <Carousel>
        <Carousel.Item>
          <img
            className="d-block rounded"
            src="https://play-lh.googleusercontent.com/HzIMEj5-OiBoO1QcN0TMjEBndBDGeIga6k4jlxY5HEOJn0cByu6w1CFwAdoZRa4pIMg=w648-h364-rw"
            alt="First slide" 
            style={{ height: '400px', width: '1300px' }}
          />
          <Carousel.Caption>
            <h3>First slide label</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block rounded"
            src="https://play-lh.googleusercontent.com/HzIMEj5-OiBoO1QcN0TMjEBndBDGeIga6k4jlxY5HEOJn0cByu6w1CFwAdoZRa4pIMg=w648-h364-rw"
            alt="First slide" 
            style={{ height: '400px', width: '1300px' }}
          />
          <Carousel.Caption>
            <h3>First slide label</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block rounded"
            src="https://play-lh.googleusercontent.com/PijOq-UHpIHR12uJ2p5yHx7kPqfTarkdvQxAvAGj4c7dHcJYYmjRxKj6ynOptrB23zs=w648-h364-rw"
            alt="Second slide" 
            style={{ height: '400px', width: '1300px' }}
          />
          <Carousel.Caption>
            <h3>TikTok
              TikTok Pte. Ltd.
              Contains adsIn-app purchases</h3>
            <p>Discover Mission: Impossible on TikTok</p>
          </Carousel.Caption>
        </Carousel.Item>
        
      </Carousel>
     
    </div>
    
    </div>
  );
}

export default Slider;
