import React from 'react';

const Footer = () => {
  return (
    <div>
      <div>
        <footer >
          <div className="container p-4 pb-0">
            <hr className="w-100 clearfix d-md-block" />
            <section className="">
              <div className="row">
                <div className="col-md-3 col-lg-3 col-xl-3 mt-3">
                  <p style={{fontFamily: "font-weight-bold"}}>Google Play Services</p>
                  <ul className="list-unstyled">
                    <li>Play Pass</li>
                    <li>Play Points</li>
                    <li>Redeem</li>
                    <li>Gift Cards</li>
                    <li>Refund Policy</li>
                  </ul>
                </div>
                <div className="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                  <p style={{fontFamily: "font-weight-bold"}}>Kids &amp; Family</p>
                  <ul className="list-unstyled mt-2">
                    <li>Parent Guide</li>
                    <li>Family sharing</li>
                  </ul>
                </div>
              </div>
            </section>
            
            
          </div>
          <div className="col-md-12 d-flex align-items-center">
  <ul className="list-inline mr-4 text-end">
    <li className="list-inline-item" style={{ marginLeft: '120px' }}>Term of Services</li>
    <li className="list-inline-item" style={{ marginLeft: '10px' }}>Privacy</li>
    <li className="list-inline-item" style={{ marginLeft: '10px' }}>About Google Play</li>
    <li className="list-inline-item" style={{ marginLeft: '10px' }}>Developers</li>
    <li className="list-inline-item" style={{ marginLeft: '10px' }}>Google Store</li>
  </ul>
  <div className="d-flex align-items-center">
    <img src="https://ssl.gstatic.com/store/images/regionflags/us.png" alt="United States Flag" className="mr-2" style={{ marginLeft: '400px' }} />
    <p className="m-0">United States (English)</p>
  </div>
</div>




        </footer>
      </div>
    </div>
  );
};

export default Footer;
