import React from 'react';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Carousel from 'react-bootstrap/Carousel';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const Recommend = () => {
  const recommendedItems = [
    {
      id: 1,
      image: "https://play-lh.googleusercontent.com/BkRfMfIRPR9hUnmIYGDgHHKjow-g18-ouP6B2ko__VnyUHSi1spcc78UtZ4sVUtBH4g=w240-h480-rw",
      title: "Adobe Acrobat Reader:",
      text: "Edit PDF"
    },
    {
      id: 2,
      image: "https://play-lh.googleusercontent.com/384jx3OL4_tqtCGZrfIB6Q5TehM0Q7TLYFsenRPfeT8f-3vicWH2BYbvaEAneaPFMMM=s256-rw",
      title: "Adobe Acrobat Reader:",
      text: "Edit PDF"
    },
    {
      id: 3,
      image: "https://play-lh.googleusercontent.com/jnlGontXypsbiVJGss56LO_IVhqUMVOQJyhp39YbDQB9_RRd_p0ap0A7mPXxazEOEu8=s256-rw",
      title: "Adobe Acrobat Reader:",
      text: "Edit PDF"
    },
    {
      id: 4,
      image: "https://play-lh.googleusercontent.com/Ml9oBSqF5mshtQYmuLEfoUaLmbTtHHcUcqPVqIusAvhstlWTu3DqR4qoQ1b72J4Aew=s256-rw",
      title: "Adobe Acrobat Reader:",
      text: "Edit PDF"
    },
    {
      id: 5,
      image: "https://play-lh.googleusercontent.com/KOtUMg1gnBZd7JZrdPxKcQaYzE6URCsBLLX_W9L5JGDVwoDx0o8apPfe4dx_--bJ72Uh=s256-rw",
      title: "Adobe Acrobat Reader:",
      text: "Edit PDF"
    },
    {
      id: 6,
      image: "https://play-lh.googleusercontent.com/zGPsbvjnofxvB1BM03NKI9N-0KHJk_rXLXSGikFmjFT63D78Z5otWEwJfqg7IWLZGtM=s256-rw",
      title: "Adobe Acrobat Reader:",
      text: "Edit PDF"
    }
  ];

  const renderCards = () => {
    return recommendedItems.map(item => (
      <Col key={item.id} xs={6} sm={4} md={3} lg={2} className="mb-4">
        <Card border="light" className="h-100">
          <Card.Img
            variant="top"
            src={item.image}
            style={{ width: '180px', height: '190px', objectFit: 'cover', borderRadius: '10px' }}
          />
          <Card.Body>
            <Card.Title className="fs-6 fw-bold">{item.title}</Card.Title>
            <Card.Text className="text-muted">{item.text}</Card.Text>
          </Card.Body>
        </Card>
      </Col>
    ));
  };

  return (
    <Container style={{ marginTop: '1rem' }}>
      <h3 className="mb-4">Recommended for You</h3>
      <Carousel>
        <Carousel.Item>
          <Row className="justify-content-center">{renderCards()}</Row>
        </Carousel.Item>
        {/* Add more carousel items for additional slides */}
      </Carousel>
    </Container>
  );
};

export default Recommend;
